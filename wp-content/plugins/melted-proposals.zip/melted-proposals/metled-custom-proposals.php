<?php
/*
Plugin Name: Melted Proposals
Version: 1.0
Plugin URI: http://www.meltedmoon.com
Description: This plugin will add new custom post type PROPOSAL.
Author: Muhammad Tajammul Hussain
Author URI: http://www.meltedmoon.com
*/

function create_melted_proposals() {
	$labels = array (
		'name' => __( 'Proposals' , 'MeltedMoon'),
        'singular_name' => __( 'Proposal' , 'MeltedMoon'),
        'edit_item' => __( 'Edit Proposal' , 'MeltedMoon'),
        'add_new_item' => __( 'Add Proposal' , 'MeltedMoon'),
        'view_item' => __( 'View Proposal' , 'MeltedMoon'),
        'search_item' => __( 'Search Proposals' , 'MeltedMoon'),
        'not_found' => __( 'No Proposal Found' , 'MeltedMoon'),
        'not_found_in_trash' => __( 'No Proposal Found in Trash' , 'MeltedMoon'),
	);
	$args = array(
		'labels' => $labels,
		'has_archive' => true,
		'public' => true,
		'hirarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'thumbnail',
			'custom-fields',
			'page-attributes'
		),
	);
	register_post_type( 'proposal', $args );
}
add_action( 'init', 'create_melted_proposals' );


function create_melted_proposal_taxonomies(){
	
	
	$labels = array (
		'name' => __( 'Tags' , 'MeltedMoon'),
        'singular_name' => __( 'Tag' , 'MeltedMoon'),
        'search_items' => __( 'Search Tags' , 'MeltedMoon'),
        'all_item' => __( 'All Tag' , 'MeltedMoon'),
        'edit_item' => __( 'Edit Tag' , 'MeltedMoon'),
        'update_item' => __( 'Update Tag' , 'MeltedMoon'),
        'add_new_item' => __( 'Add New Tag' , 'MeltedMoon'),
        'new_item_name' => __( 'New Tag Title' , 'MeltedMoon'),
        'menu_name' => __( 'Tags' , 'MeltedMoon'),
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'hirarchical' => false,
		'rewrite' => array(
			'slug' => 'tags',
		),
	);
	register_taxonomy( 'proposal_tag', 'proposal', $args );
	
	/*
	$labels = array (
		'name' => __( 'Gender' , 'MeltedMoon'),
        'singular_name' => __( 'Gender' , 'MeltedMoon'),
        'search_items' => __( 'Search Gender' , 'MeltedMoon'),
        'all_item' => __( 'All Gender' , 'MeltedMoon'),
        'edit_item' => __( 'Edit Gender' , 'MeltedMoon'),
        'update_item' => __( 'Update Gender' , 'MeltedMoon'),
        'add_new_item' => __( 'Add New Gender' , 'MeltedMoon'),
        'new_item_name' => __( 'New Gender Title' , 'MeltedMoon'),
        'menu_name' => __( 'Gender' , 'MeltedMoon'),
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'hirarchical' => false,
		'rewrite' => array(
			'slug' => 'gender',
		),
	);
	register_taxonomy( 'proposal_gender', 'melted_proposal', $args );
	
	$labels = array (
		'name' => __( 'Educations' , 'MeltedMoon'),
        'singular_name' => __( 'Education' , 'MeltedMoon'),
        'search_items' => __( 'Search Educations' , 'MeltedMoon'),
        'all_item' => __( 'All Education' , 'MeltedMoon'),
        'edit_item' => __( 'Edit Education' , 'MeltedMoon'),
        'update_item' => __( 'Update Education' , 'MeltedMoon'),
        'add_new_item' => __( 'Add New Education' , 'MeltedMoon'),
        'new_item_name' => __( 'New Education Title' , 'MeltedMoon'),
        'menu_name' => __( 'Educations' , 'MeltedMoon'),
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'hirarchical' => false,
		'rewrite' => array(
			'slug' => 'educations',
		),
	);
	register_taxonomy( 'proposal_education', 'melted_proposal', $args );
	
	$labels = array (
		'name' => __( 'Ages' , 'MeltedMoon'),
        'singular_name' => __( 'Age' , 'MeltedMoon'),
        'search_items' => __( 'Search Ages' , 'MeltedMoon'),
        'all_item' => __( 'All Age' , 'MeltedMoon'),
        'edit_item' => __( 'Edit Age' , 'MeltedMoon'),
        'update_item' => __( 'Update Age' , 'MeltedMoon'),
        'add_new_item' => __( 'Add New Age' , 'MeltedMoon'),
        'new_item_name' => __( 'New Age Title' , 'MeltedMoon'),
        'menu_name' => __( 'Ages' , 'MeltedMoon'),
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'hirarchical' => false,
		'rewrite' => array(
			'slug' => 'ages',
		),
	);
	register_taxonomy( 'proposal_age', 'melted_proposal', $args );
	*/
}
add_action( 'init', 'create_melted_proposal_taxonomies' );

/*function foobar_func( $post_id ){
	return the_title();
}
add_shortcode( 'foobar', 'foobar_func' );*/



?>







