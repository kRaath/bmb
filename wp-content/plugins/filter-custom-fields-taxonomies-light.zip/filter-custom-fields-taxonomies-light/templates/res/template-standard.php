<div style="float:left;">
	<a href="#the_permalink#">#thumbnail#</a>
</div>
<h3><a href="#the_permalink#">#the_title#</a></h3>

<small>Published #the_date#, by #the_author#</small>
#the_excerpt#
<small>#count_comments# Comments</small></p>
