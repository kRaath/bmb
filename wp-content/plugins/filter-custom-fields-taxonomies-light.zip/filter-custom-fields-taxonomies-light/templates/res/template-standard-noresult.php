<h2>Nothing found :(</h2>
<p>Unfortunatly, we weren't able to find some blogposts for your search query. Please try again.</p>
