
<?php get_template_part( 'content', 'proposal' ); ?>